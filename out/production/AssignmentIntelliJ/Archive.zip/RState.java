public interface RState
{
    public String genStatusMessage();
}
